# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Reward terms specific to the velocity-tracking locomotion task."""

from __future__ import annotations

import torch
from typing import TYPE_CHECKING

from isaaclab.assets import Articulation
from isaaclab.managers import SceneEntityCfg
from isaaclab.sensors import ContactSensor

from .observations import _gait_phase

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedRLEnv


def joint_power_l1(env: "ManagerBasedRLEnv", asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")) -> torch.Tensor:
    """L1 penalty on positive mechanical power ``max(τ · q̇, 0)`` summed over joints."""
    asset: Articulation = env.scene[asset_cfg.name]
    torque = asset.data.applied_torque[:, asset_cfg.joint_ids]
    vel = asset.data.joint_vel[:, asset_cfg.joint_ids]
    return torch.clamp(torque * vel, min=0.0).sum(dim=-1)


def feet_swing_phase(
    env: "ManagerBasedRLEnv",
    command_name: str,
    sensor_cfg: SceneEntityCfg,
    frequency: float = 2.0,
    contact_force_threshold: float = 1.0,
    cmd_threshold: float = 0.1,
) -> torch.Tensor:
    """Reward when foot contact pattern matches the commanded gait phase.

    The first body in ``sensor_cfg.body_ids`` is treated as the left foot and
    the second as the right foot. During phase ∈ [0, 0.5) the left foot is
    expected to be in swing (no contact), and during [0.5, 1) the right foot
    is. The reward is 0 when the commanded velocity magnitude is below
    ``cmd_threshold`` so the policy is allowed to stand still on zero command.
    """
    contact_sensor: ContactSensor = env.scene.sensors[sensor_cfg.name]
    forces = contact_sensor.data.net_forces_w[:, sensor_cfg.body_ids, :].norm(dim=-1)
    in_contact = forces > contact_force_threshold  # (num_envs, 2)

    phase = _gait_phase(env, frequency)
    left_should_swing = phase < 0.5
    right_should_swing = ~left_should_swing

    # foot contact correct iff (in_contact == NOT should_swing) — i.e. swing matches no-contact
    left_correct = in_contact[:, 0] != left_should_swing
    right_correct = in_contact[:, 1] != right_should_swing
    reward = 0.5 * (left_correct.float() + right_correct.float())

    cmd = env.command_manager.get_command(command_name)
    cmd_norm = torch.norm(cmd[:, :3], dim=1)
    return reward * (cmd_norm > cmd_threshold).float()
