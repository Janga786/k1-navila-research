# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""K1 vision-based velocity-tracking env config aligned with VLN-CE-Isaac benchmark.

Built so the trained policy drops into the benchmark's
``k1_matterport_vision`` task without an observation adapter:

  * 235-dim policy observation in benchmark order
    base_lin_vel(3) + base_ang_vel(3) + projected_gravity(3) + velocity_commands(3)
    + joint_pos_rel(12) + joint_vel_rel(12) + last_action(12) + height_scan(187)
    (187 = 17 x 11 inclusive grid from GridPatternCfg(size=(1.6, 1.0), resolution=0.1))
  * 12-DoF leg joint position action, scale 0.5, use_default_offset
  * RayCaster height scanner: 17x11 grid, 0.1m resolution, attached to Trunk
  * bad_orientation terminates at 1.3 rad (matches benchmark relaxed threshold)
  * K1-tailored gentle terrain curriculum (random_rough + small slopes) so the
    policy can survive long enough at random init to actually learn. The Isaac
    Lab ``ROUGH_TERRAINS_CFG`` preset includes 0.23 m stairs which are too
    steep for K1's 0.55-m frame and cause every reset to terminate at step 1.
  * Booster-Gym stable PPO settings: action_rate weight -1.0 (vs legged-loco's
    -0.005 which let the v3 50k run diverge to action_rate ~ -3e15)
"""

from __future__ import annotations

import math

import isaaclab.sim as sim_utils
import isaaclab.terrains as terrain_gen
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import RewardTermCfg as RewTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.sensors import RayCasterCfg, patterns
from isaaclab.terrains import TerrainGeneratorCfg, TerrainImporterCfg
from isaaclab.utils import configclass
from isaaclab.utils.noise import AdditiveUniformNoiseCfg as Unoise


# ---------------------------------------------------------------------------
# K1-tailored gentle terrain. Built specifically for the 0.55-m-tall K1:
#   * No stairs, no boxes — a stair/box edge under K1's feet at spawn caused
#     the initial training run to terminate every episode at step 1 (mean
#     episode length stuck at 1.00 for 1000 iters with bad_orientation 80%).
#   * Just random_rough (gentle bumps) + small slopes. The curriculum's row 0
#     is essentially flat (1-2 cm noise) so a random-init policy can survive
#     long enough to learn; row 9 is rough enough (10-12 cm) for the
#     height_scan obs to carry meaningful signal.
# Compare to ROUGH_TERRAINS_CFG which uses 0.23 m step heights — way too
# steep for K1, which has ~0.25 m max ankle lift.
# ---------------------------------------------------------------------------
K1_VLNCE_TERRAINS_CFG = TerrainGeneratorCfg(
    size=(8.0, 8.0),
    border_width=20.0,
    num_rows=10,
    num_cols=20,
    horizontal_scale=0.1,
    vertical_scale=0.005,
    slope_threshold=0.75,
    use_cache=False,
    curriculum=True,
    sub_terrains={
        "random_rough": terrain_gen.HfRandomUniformTerrainCfg(
            proportion=0.6,
            noise_range=(0.01, 0.06),
            noise_step=0.01,
            border_width=0.25,
        ),
        "slope_up": terrain_gen.HfPyramidSlopedTerrainCfg(
            proportion=0.2,
            slope_range=(0.0, 0.15),
            platform_width=2.0,
            border_width=0.25,
        ),
        "slope_down": terrain_gen.HfInvertedPyramidSlopedTerrainCfg(
            proportion=0.2,
            slope_range=(0.0, 0.15),
            platform_width=2.0,
            border_width=0.25,
        ),
    },
)

from booster_train.assets.robots.booster import BOOSTER_K1_LOCOMOTION_CFG
from booster_train.tasks.manager_based.velocity.velocity_env_cfg import (
    LocomotionVelocityFlatEnvCfg,
)

import booster_train.tasks.manager_based.velocity.mdp as mdp


# ---------------------------------------------------------------------------
# Observations — exact match to benchmark's k1_matterport_vision PolicyCfg.
# Order matters: terms are concatenated in definition order.
# ---------------------------------------------------------------------------
@configclass
class K1VisionVLNCEObservationsCfg:

    @configclass
    class PolicyCfg(ObsGroup):
        """208-dim actor observation (no history stacking, matches benchmark)."""

        base_lin_vel = ObsTerm(
            func=mdp.base_lin_vel, noise=Unoise(n_min=-0.1, n_max=0.1)
        )
        base_ang_vel = ObsTerm(
            func=mdp.base_ang_vel, noise=Unoise(n_min=-0.2, n_max=0.2)
        )
        projected_gravity = ObsTerm(
            func=mdp.projected_gravity, noise=Unoise(n_min=-0.05, n_max=0.05)
        )
        velocity_commands = ObsTerm(
            func=mdp.generated_commands, params={"command_name": "base_velocity"}
        )
        joint_pos = ObsTerm(
            func=mdp.joint_pos_rel, noise=Unoise(n_min=-0.01, n_max=0.01)
        )
        joint_vel = ObsTerm(
            func=mdp.joint_vel_rel, noise=Unoise(n_min=-1.5, n_max=1.5)
        )
        actions = ObsTerm(func=mdp.last_action)
        height_scan = ObsTerm(
            func=mdp.height_scan,
            params={"sensor_cfg": SceneEntityCfg("height_scanner"), "offset": 0.5},
            clip=(-1.0, 1.0),
            noise=Unoise(n_min=-0.1, n_max=0.1),
        )

        def __post_init__(self):
            self.enable_corruption = True
            self.concatenate_terms = True
            self.history_length = 0
            self.flatten_history_dim = False

    @configclass
    class CriticCfg(ObsGroup):
        """Privileged 208-dim critic obs (same terms as policy, no noise)."""

        base_lin_vel = ObsTerm(func=mdp.base_lin_vel)
        base_ang_vel = ObsTerm(func=mdp.base_ang_vel)
        projected_gravity = ObsTerm(func=mdp.projected_gravity)
        velocity_commands = ObsTerm(
            func=mdp.generated_commands, params={"command_name": "base_velocity"}
        )
        joint_pos = ObsTerm(func=mdp.joint_pos_rel)
        joint_vel = ObsTerm(func=mdp.joint_vel_rel)
        actions = ObsTerm(func=mdp.last_action)
        height_scan = ObsTerm(
            func=mdp.height_scan,
            params={"sensor_cfg": SceneEntityCfg("height_scanner"), "offset": 0.5},
            clip=(-1.0, 1.0),
        )

        def __post_init__(self):
            self.enable_corruption = False
            self.concatenate_terms = True

    policy: PolicyCfg = PolicyCfg()
    critic: CriticCfg = CriticCfg()


# ---------------------------------------------------------------------------
# Actions — match benchmark: action_scale = 0.5
# ---------------------------------------------------------------------------
@configclass
class K1VisionVLNCEActionsCfg:

    joint_pos = mdp.JointPositionActionCfg(
        asset_name="robot",
        joint_names=[".*_Hip_Pitch", ".*_Hip_Roll", ".*_Hip_Yaw",
                     ".*_Knee_Pitch", ".*_Ankle_Pitch", ".*_Ankle_Roll"],
        scale=0.5,
        use_default_offset=True,
    )


# ---------------------------------------------------------------------------
# Terminations — bad_orientation@1.3 rad matches benchmark's relaxed threshold.
# Same base_height termination as booster_train flat task.
# ---------------------------------------------------------------------------
@configclass
class K1VisionVLNCETerminationsCfg:

    time_out = DoneTerm(func=mdp.time_out, time_out=True)
    base_below = DoneTerm(
        func=mdp.root_height_below_minimum, params={"minimum_height": 0.30}
    )
    bad_orientation = DoneTerm(
        func=mdp.bad_orientation, params={"limit_angle": 1.3}
    )


# ---------------------------------------------------------------------------
# Env config — extends the flat-ground base, swaps in vision obs/actions/terms,
# adds RayCaster + rough terrain curriculum in __post_init__.
# ---------------------------------------------------------------------------
@configclass
class K1VisionVLNCEEnvCfg(LocomotionVelocityFlatEnvCfg):

    observations: K1VisionVLNCEObservationsCfg = K1VisionVLNCEObservationsCfg()
    actions: K1VisionVLNCEActionsCfg = K1VisionVLNCEActionsCfg()
    terminations: K1VisionVLNCETerminationsCfg = K1VisionVLNCETerminationsCfg()

    def __post_init__(self):
        super().__post_init__()

        self.scene.robot = BOOSTER_K1_LOCOMOTION_CFG.replace(
            prim_path="{ENV_REGEX_NS}/Robot"
        )

        self.scene.height_scanner = RayCasterCfg(
            prim_path="{ENV_REGEX_NS}/Robot/Trunk",
            offset=RayCasterCfg.OffsetCfg(pos=(0.0, 0.0, 20.0)),
            attach_yaw_only=True,
            pattern_cfg=patterns.GridPatternCfg(resolution=0.1, size=(1.6, 1.0)),
            debug_vis=False,
            mesh_prim_paths=["/World/ground"],
            update_period=self.decimation * self.sim.dt,
        )

        self.scene.terrain.terrain_type = "generator"
        self.scene.terrain.terrain_generator = K1_VLNCE_TERRAINS_CFG
        self.scene.terrain.max_init_terrain_level = 0


@configclass
class K1VisionVLNCEEnvCfg_PLAY(K1VisionVLNCEEnvCfg):
    """Smaller deterministic config for visual playback / smoke tests."""

    def __post_init__(self):
        super().__post_init__()
        self.scene.num_envs = 16
        self.scene.env_spacing = 2.5
        self.observations.policy.enable_corruption = False
        self.events.push_robot = None
        self.commands.base_velocity.ranges.lin_vel_x = (0.5, 0.5)
        self.commands.base_velocity.ranges.lin_vel_y = (0.0, 0.0)
        self.commands.base_velocity.ranges.ang_vel_z = (0.0, 0.0)
