# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""MDP terms for the velocity-tracking task.

Re-exports the base Isaac Lab MDP namespace plus the locomotion-velocity helpers
(``track_lin_vel_xy_yaw_frame_exp``, ``track_ang_vel_z_world_exp``, ``feet_slide``)
and adds gait-phase observations / rewards used by the Booster-Gym recipe.
"""

from isaaclab.envs.mdp import *  # noqa: F401, F403
from isaaclab_tasks.manager_based.locomotion.velocity.mdp import (  # noqa: F401
    feet_slide,
    track_ang_vel_z_world_exp,
    track_lin_vel_xy_yaw_frame_exp,
)

from .observations import *  # noqa: F401, F403
from .rewards import *  # noqa: F401, F403
