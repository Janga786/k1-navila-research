# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""K1 velocity-tracking config for benchmark integration, v3 (start from
what WORKS).

Philosophy: the VLN-CE-v0 (vlnce_env_cfg.py) config redesigned the
observation space from scratch to match the NaVILA-Bench wrapper's 235-dim
single-step format. In doing so it dropped:

  * gait_phase     — 2 Hz cos/sin clock; without it the policy can't learn
                     alternating leg timing (Booster-Gym §III-B3).
  * history_length=5, flatten_history_dim=True — 5-frame history lets the
                     policy infer base_lin_vel from proprio.
  * action_scale=0.25 (got bumped to 0.5).
  * empirical_normalization=True (was False so the state_dict ports to
                     rsl_rl 2.0.2; tradeoff didn't pay off).
  * flat terrain (got swapped for a rough curriculum).

Net effect: the trained `model_28000.pt` policy lunges forward for ~0.8s
then collapses. Confirmed by MuJoCo sim-to-sim playback on 2026-05-19.

This v3 starts from the WORKING `LocomotionVelocityFlatEnvCfg` and adds
ONE thing at a time:

  * Adds an EXTRA observation group `vision` containing a 160-dim height
    scan (16x10 grid, 0.1 m resolution). This group is NOT in the actor
    or critic obs — it exists so the wrapper can read it later for
    benchmark integration. The policy's 47-dim per-step / 235-dim
    history-flattened obs is unchanged from the working config.
  * Adds a height_scanner RayCaster to the scene at the same prim path
    (Trunk).
  * Relaxes bad_orientation to 1.3 rad to match the benchmark's
    relaxed threshold (the working config used 1.0 rad).
  * Keeps the flat plane terrain — exactly what the working policy was
    trained on.

The benchmark integration (merging history+gait into the wrapper's
expected obs layout) is left as a follow-up. First we need a policy
that actually walks.
"""

from __future__ import annotations

import isaaclab.sim as sim_utils
import isaaclab.terrains as terrain_gen
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.sensors import RayCasterCfg, patterns
from isaaclab.terrains import TerrainGeneratorCfg
from isaaclab.utils import configclass

from booster_train.assets.robots.booster import BOOSTER_K1_LOCOMOTION_CFG
from booster_train.tasks.manager_based.velocity.velocity_env_cfg import (
    LocomotionVelocityFlatEnvCfg,
    ObservationsCfg,
    TerminationsCfg,
)

import booster_train.tasks.manager_based.velocity.mdp as mdp


# Tougher terrain for generalisation stress-tests. ~2-3x the noise and
# slope of K1_VLNCE_TERRAINS_CFG. Still no stairs/boxes (K1 max ankle lift
# is ~0.25 m so a stair-edge spawn is an instant fall).
K1_EXTRA_ROUGH_TERRAINS_CFG = TerrainGeneratorCfg(
    size=(8.0, 8.0),
    border_width=20.0,
    num_rows=10,
    num_cols=20,
    horizontal_scale=0.1,
    vertical_scale=0.005,
    slope_threshold=0.75,
    use_cache=False,
    curriculum=True,
    sub_terrains={
        "random_rough": terrain_gen.HfRandomUniformTerrainCfg(
            proportion=0.5,
            noise_range=(0.04, 0.15),  # 4-15 cm (was 1-6 cm)
            noise_step=0.02,
            border_width=0.25,
        ),
        "slope_up": terrain_gen.HfPyramidSlopedTerrainCfg(
            proportion=0.25,
            slope_range=(0.10, 0.30),  # was 0.0-0.15
            platform_width=2.0,
            border_width=0.25,
        ),
        "slope_down": terrain_gen.HfInvertedPyramidSlopedTerrainCfg(
            proportion=0.25,
            slope_range=(0.10, 0.30),
            platform_width=2.0,
            border_width=0.25,
        ),
    },
)


# ---------------------------------------------------------------------------
# Vision observation group — 16x10 height-scan grid, 0.1 m resolution.
# Total = 160 floats. Lives on the env as a separate ObsGroup so it doesn't
# pollute the actor/critic obs that the working policy depends on.
# ---------------------------------------------------------------------------
@configclass
class _VisionObsCfg(ObsGroup):
    height_scan = ObsTerm(
        func=mdp.height_scan,
        params={"sensor_cfg": SceneEntityCfg("height_scanner"), "offset": 0.5},
        clip=(-1.0, 1.0),
    )

    def __post_init__(self):
        self.enable_corruption = False
        self.concatenate_terms = True


@configclass
class K1VisionVLNCEv3ObservationsCfg(ObservationsCfg):
    """Working PolicyCfg + CriticCfg unchanged, plus a vision side-channel.

    Inherits the working 47-dim per-step PolicyCfg with 5-frame history
    (235 dim flattened) and the working CriticCfg. Only adds a separate
    `vision` group, which is not fed to the actor or critic during training.
    """

    vision: _VisionObsCfg = _VisionObsCfg()


# ---------------------------------------------------------------------------
# Terminations — copy the working base, relax bad_orientation 1.0 → 1.3 rad
# to match the benchmark's threshold so an Isaac-Sim-side smoke run with
# this checkpoint plays under identical fall criteria.
# ---------------------------------------------------------------------------
@configclass
class K1VisionVLNCEv3TerminationsCfg(TerminationsCfg):

    def __post_init__(self):
        self.bad_orientation = DoneTerm(
            func=mdp.bad_orientation, params={"limit_angle": 1.3}
        )


# ---------------------------------------------------------------------------
# Env — subclass the working flat-ground base, swap in K1 robot + add the
# height_scanner sensor + override observations & terminations.
# ---------------------------------------------------------------------------
@configclass
class K1VisionVLNCEv3EnvCfg(LocomotionVelocityFlatEnvCfg):

    observations: K1VisionVLNCEv3ObservationsCfg = K1VisionVLNCEv3ObservationsCfg()
    terminations: K1VisionVLNCEv3TerminationsCfg = K1VisionVLNCEv3TerminationsCfg()

    def __post_init__(self):
        super().__post_init__()

        # K1 robot (matches what the working policy was trained on)
        self.scene.robot = BOOSTER_K1_LOCOMOTION_CFG.replace(
            prim_path="{ENV_REGEX_NS}/Robot"
        )

        # Add the height_scanner — 16 x 10 grid at 0.1 m resolution = 160
        # rays. Placed 20 m above Trunk so any sane ground geometry returns
        # a hit. attach_yaw_only so the grid stays world-axis aligned.
        # Casts against /World/ground (the flat plane terrain).
        self.scene.height_scanner = RayCasterCfg(
            prim_path="{ENV_REGEX_NS}/Robot/Trunk",
            offset=RayCasterCfg.OffsetCfg(pos=(0.0, 0.0, 20.0)),
            attach_yaw_only=True,
            pattern_cfg=patterns.GridPatternCfg(
                resolution=0.1, size=(1.5, 0.9)
            ),
            debug_vis=False,
            mesh_prim_paths=["/World/ground"],
            update_period=self.decimation * self.sim.dt,
        )


@configclass
class K1VisionVLNCEv3EnvCfg_PLAY(K1VisionVLNCEv3EnvCfg):
    """Deterministic single-env config for visual playback / sanity check."""

    def __post_init__(self):
        super().__post_init__()
        self.scene.num_envs = 16
        self.scene.env_spacing = 2.5
        self.observations.policy.enable_corruption = False
        self.events.push_robot = None
        self.commands.base_velocity.ranges.lin_vel_x = (0.5, 0.5)
        self.commands.base_velocity.ranges.lin_vel_y = (0.0, 0.0)
        self.commands.base_velocity.ranges.ang_vel_z = (0.0, 0.0)


@configclass
class K1VisionVLNCEv3EnvCfg_ExtraRoughPlay(K1VisionVLNCEv3EnvCfg_PLAY):
    """Harder generalisation test: 4-15 cm random bumps + 0.10-0.30 rad
    slopes. Heightfield curriculum row 9 has the deepest bumps and the
    steepest pyramids — for a policy that's only seen flat ground this
    should expose any latent fragility."""

    def __post_init__(self):
        super().__post_init__()
        self.scene.terrain.terrain_type = "generator"
        self.scene.terrain.terrain_generator = K1_EXTRA_ROUGH_TERRAINS_CFG
        self.scene.terrain.max_init_terrain_level = 0


@configclass
class K1VisionVLNCEv3EnvCfg_RoughPlay(K1VisionVLNCEv3EnvCfg_PLAY):
    """Generalisation test: same v3 policy on the K1-tailored gentle rough
    terrain (random_rough 1-6 cm + slopes ±0-0.15 rad, no stairs).

    The policy was trained on flat ground only; this exercises whether the
    proprioceptive history + gait clock are robust to unseen terrain. The
    height_scanner stays attached to the Trunk and casts against the
    generator's heightfield mesh.
    """

    def __post_init__(self):
        super().__post_init__()
        # Import here to avoid circular import at module load.
        from booster_train.tasks.manager_based.velocity.robots.k1.vlnce_env_cfg import (
            K1_VLNCE_TERRAINS_CFG,
        )
        self.scene.terrain.terrain_type = "generator"
        self.scene.terrain.terrain_generator = K1_VLNCE_TERRAINS_CFG
        self.scene.terrain.max_init_terrain_level = 0
        # Re-target the height_scanner mesh to the generator's terrain mesh.
        # On flat ground we cast against /World/ground; for the generator
        # the same mesh path is used by Isaac Lab so no change needed here.
