# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

import gymnasium as gym


gym.register(
    id="Booster-K1-Velocity-v0",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.env_cfg:K1FlatVelocityEnvCfg",
        "rsl_rl_cfg_entry_point": f"{__name__}.ppo_cfg:K1VelocityPPORunnerCfg",
    },
)


gym.register(
    id="Booster-K1-Velocity-v0-Play",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.env_cfg:K1FlatVelocityEnvCfg_PLAY",
        "rsl_rl_cfg_entry_point": f"{__name__}.ppo_cfg:K1VelocityPPORunnerCfg",
    },
)


gym.register(
    id="Booster-K1-Velocity-Vision-VLNCE-v0",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.vlnce_env_cfg:K1VisionVLNCEEnvCfg",
        "rsl_rl_cfg_entry_point": f"{__name__}.vlnce_ppo_cfg:K1VisionVLNCEPPORunnerCfg",
    },
)


gym.register(
    id="Booster-K1-Velocity-Vision-VLNCE-v0-Play",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.vlnce_env_cfg:K1VisionVLNCEEnvCfg_PLAY",
        "rsl_rl_cfg_entry_point": f"{__name__}.vlnce_ppo_cfg:K1VisionVLNCEPPORunnerCfg",
    },
)


gym.register(
    id="Booster-K1-Velocity-Vision-VLNCE-v3",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.vlnce_v3_env_cfg:K1VisionVLNCEv3EnvCfg",
        "rsl_rl_cfg_entry_point": f"{__name__}.vlnce_v3_ppo_cfg:K1VisionVLNCEv3PPORunnerCfg",
    },
)


gym.register(
    id="Booster-K1-Velocity-Vision-VLNCE-v3-Play",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.vlnce_v3_env_cfg:K1VisionVLNCEv3EnvCfg_PLAY",
        "rsl_rl_cfg_entry_point": f"{__name__}.vlnce_v3_ppo_cfg:K1VisionVLNCEv3PPORunnerCfg",
    },
)


gym.register(
    id="Booster-K1-Velocity-Vision-VLNCE-v3-RoughPlay",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.vlnce_v3_env_cfg:K1VisionVLNCEv3EnvCfg_RoughPlay",
        "rsl_rl_cfg_entry_point": f"{__name__}.vlnce_v3_ppo_cfg:K1VisionVLNCEv3PPORunnerCfg",
    },
)


gym.register(
    id="Booster-K1-Velocity-Vision-VLNCE-v3-ExtraRoughPlay",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.vlnce_v3_env_cfg:K1VisionVLNCEv3EnvCfg_ExtraRoughPlay",
        "rsl_rl_cfg_entry_point": f"{__name__}.vlnce_v3_ppo_cfg:K1VisionVLNCEv3PPORunnerCfg",
    },
)
