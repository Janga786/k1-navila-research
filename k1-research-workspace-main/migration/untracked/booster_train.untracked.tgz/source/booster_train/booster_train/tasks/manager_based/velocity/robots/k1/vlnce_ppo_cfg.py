# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""PPO config for the K1 vision-based VLN-CE-Isaac-compat task.

Same actor/critic arch + PPO hyperparameters as ``K1VelocityPPORunnerCfg``,
with:
  * ``empirical_normalization=False`` so the saved state_dict drops into the
    benchmark's rsl_rl 2.0.2 ActorCritic with no normalization layer mismatch
  * ``max_iterations=30000`` (watcher in launch script enforces a plateau-based
    early stop, see ~/Projects/k1_research/scripts/train_k1_vlnce.sh)
  * ``save_interval=2000`` so we never lose more than ~3 min of progress
  * dedicated ``experiment_name`` so logs land in ``logs/rsl_rl/k1_velocity_vlnce/``
"""

from isaaclab.utils import configclass
from isaaclab_rl.rsl_rl import (
    RslRlOnPolicyRunnerCfg,
    RslRlPpoActorCriticCfg,
    RslRlPpoAlgorithmCfg,
)


@configclass
class K1VisionVLNCEPPORunnerCfg(RslRlOnPolicyRunnerCfg):
    num_steps_per_env = 24
    max_iterations = 30000
    save_interval = 2000
    experiment_name = "k1_velocity_vlnce"
    empirical_normalization = False
    policy = RslRlPpoActorCriticCfg(
        init_noise_std=1.0,
        actor_hidden_dims=[512, 256, 128],
        critic_hidden_dims=[512, 256, 128],
        activation="elu",
    )
    algorithm = RslRlPpoAlgorithmCfg(
        value_loss_coef=1.0,
        use_clipped_value_loss=True,
        clip_param=0.2,
        entropy_coef=0.01,
        num_learning_epochs=5,
        num_mini_batches=4,
        learning_rate=1.0e-3,
        schedule="adaptive",
        gamma=0.99,
        lam=0.95,
        desired_kl=0.01,
        max_grad_norm=1.0,
    )
