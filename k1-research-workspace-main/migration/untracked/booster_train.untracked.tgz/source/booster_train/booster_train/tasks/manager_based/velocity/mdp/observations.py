# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Observation terms specific to the velocity-tracking locomotion task."""

from __future__ import annotations

import math

import torch
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedRLEnv


def _gait_phase(env: "ManagerBasedRLEnv", frequency: float) -> torch.Tensor:
    """Return a per-env scalar phase in [0, 1) at the requested gait frequency.

    Each env gets a random phase offset (set lazily on first call) so envs are
    desynchronised. The phase advances with ``episode_length_buf`` and so resets
    when the episode resets.
    """
    if not hasattr(env, "_gait_phase_offset") or env._gait_phase_offset.shape[0] != env.num_envs:
        env._gait_phase_offset = torch.rand(env.num_envs, device=env.device)
    t = env.episode_length_buf.to(env.device).float() * env.step_dt
    phase = (t * frequency + env._gait_phase_offset) % 1.0
    return phase


def gait_phase(env: "ManagerBasedRLEnv", frequency: float = 2.0) -> torch.Tensor:
    """Two-dim observation ``(cos(2π φ), sin(2π φ))`` encoding the current gait phase."""
    phase = _gait_phase(env, frequency)
    angle = 2.0 * math.pi * phase
    return torch.stack([torch.cos(angle), torch.sin(angle)], dim=-1)
