# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""K1-specific velocity-tracking env configs."""

from isaaclab.utils import configclass

from booster_train.assets.robots.booster import BOOSTER_K1_LOCOMOTION_CFG
from booster_train.tasks.manager_based.velocity.velocity_env_cfg import (
    LocomotionVelocityFlatEnvCfg,
)


@configclass
class K1FlatVelocityEnvCfg(LocomotionVelocityFlatEnvCfg):
    """K1 (12-DoF locomotion URDF) walking on a flat plane."""

    def __post_init__(self):
        super().__post_init__()
        self.scene.robot = BOOSTER_K1_LOCOMOTION_CFG.replace(prim_path="{ENV_REGEX_NS}/Robot")


@configclass
class K1FlatVelocityEnvCfg_PLAY(K1FlatVelocityEnvCfg):
    """Smaller, deterministic version for visual playback."""

    def __post_init__(self):
        super().__post_init__()
        self.scene.num_envs = 32
        self.scene.env_spacing = 2.5
        self.observations.policy.enable_corruption = False
        self.events.push_robot = None
        self.commands.base_velocity.ranges.lin_vel_x = (0.5, 0.5)
        self.commands.base_velocity.ranges.lin_vel_y = (0.0, 0.0)
        self.commands.base_velocity.ranges.ang_vel_z = (0.0, 0.0)
