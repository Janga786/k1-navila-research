# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

from isaaclab.utils import configclass

from booster_train.tasks.manager_based.velocity.agents.rsl_rl_ppo_cfg import VelocityPPORunnerCfg


@configclass
class K1VelocityPPORunnerCfg(VelocityPPORunnerCfg):
    experiment_name = "k1_velocity"
    max_iterations = 10000
