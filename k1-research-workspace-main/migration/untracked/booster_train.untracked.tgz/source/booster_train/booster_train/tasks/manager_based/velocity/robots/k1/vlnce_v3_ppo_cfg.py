# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""PPO config for K1 VLN-CE v3 (start-from-what-works variant).

Inherits the working ``VelocityPPORunnerCfg`` (which trained the
reward-103 walking policy) verbatim and only changes:
  * experiment_name -> ``k1_velocity_vlnce_v3`` so logs land in a fresh
    directory.
  * max_iterations = 5000 (quick-test budget; bump to 30000 once the
    iter-1000 walking check passes).
  * save_interval = 500 so we have ~10 checkpoints over the 5k run.

CRITICAL: keeps ``empirical_normalization=True``. The previous vlnce
ppo cfg disabled it to make state_dict load into rsl_rl 2.0.2 — that
tradeoff broke training. Benchmark integration is a later concern; for
now train a policy that walks.
"""

from isaaclab.utils import configclass

from booster_train.tasks.manager_based.velocity.agents.rsl_rl_ppo_cfg import (
    VelocityPPORunnerCfg,
)


@configclass
class K1VisionVLNCEv3PPORunnerCfg(VelocityPPORunnerCfg):
    experiment_name = "k1_velocity_vlnce_v3"
    max_iterations = 5000
    save_interval = 500
