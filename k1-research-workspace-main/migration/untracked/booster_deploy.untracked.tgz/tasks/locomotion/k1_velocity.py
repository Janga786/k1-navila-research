"""K1 velocity-tracking policy deploy adapter.

Loads the policy trained under ``Booster-K1-Velocity-v0`` (Booster-Gym /
NaVILA observation layout) and produces 22-DoF MuJoCo joint targets by
scattering the 12 leg actions into the K1 22-DoF default pose (arms held).

Policy I/O
----------
- Per-step actor obs (47 dims):
    cmd(3) | gait(2) | gravity(3) | ang_vel(3) | joint_pos_rel(12)
    | joint_vel(12) | last_action(12)
- History layout: each term keeps its own length-5 history; the final
  flattened obs concatenates ``[term_t0..t4]`` per term (term-major).
  Total = 235.
- Action: 12 leg targets (offsets), scaled by ``action_scale`` and added
  to the leg defaults.
"""

from __future__ import annotations

from dataclasses import MISSING
import math
import os
import torch

from booster_deploy.controllers.base_controller import BaseController, Policy
from booster_deploy.controllers.controller_cfg import (
    ControllerCfg, PolicyCfg, VelocityCommandCfg,
)
from booster_deploy.robots.booster import K1_CFG
from booster_deploy.utils.isaaclab.configclass import configclass
from booster_deploy.utils.isaaclab import math as lab_math


# Per-step term order and dims (must match training env_cfg PolicyCfg).
_TERM_DIMS = (3, 2, 3, 3, 12, 12, 12)  # cmd, gait, gravity, ang_vel, jp, jv, last_act
_PER_STEP_DIM = sum(_TERM_DIMS)  # 47


class K1VelocityPolicy(Policy):
    """Velocity-tracking policy with NaVILA / Booster-Gym observation layout."""

    def __init__(self, cfg: "K1VelocityPolicyCfg", controller: BaseController):
        super().__init__(cfg, controller)
        self.cfg = cfg
        self.robot = controller.robot

        ckpt = self.cfg.checkpoint_path
        if not os.path.isabs(ckpt):
            ckpt = os.path.join(self.task_path, ckpt)
        self._model: torch.jit.ScriptModule = torch.jit.load(ckpt, map_location="cpu")
        self._model.eval()

        self.action_scale = cfg.action_scale
        self.gait_freq_hz = cfg.gait_freq_hz
        self.history_length = cfg.actor_obs_history_length

        # 12 leg joints in the order Isaac Lab assigns them (verified via probe).
        self.policy_joint_names: list[str] = list(cfg.policy_joint_names)
        assert len(self.policy_joint_names) == 12

        self.real_indices = torch.tensor(
            [self.robot.cfg.joint_names.index(n) for n in self.policy_joint_names],
            dtype=torch.long,
        )

        self.last_raw_action = torch.zeros(12, dtype=torch.float32)
        self._step_buf: torch.Tensor | None = None  # (history_length, 47)
        self._t = 0.0

        # Precompute term offsets for term-major flatten.
        offs = [0]
        for d in _TERM_DIMS:
            offs.append(offs[-1] + d)
        self._term_offsets = offs  # length len(_TERM_DIMS)+1

    def reset(self) -> None:
        self.last_raw_action.zero_()
        self._step_buf = None
        self._t = 0.0

    def _per_step_obs(self) -> torch.Tensor:
        dof_pos = self.robot.data.joint_pos
        dof_vel = self.robot.data.joint_vel
        base_quat = self.robot.data.root_quat_w
        base_ang_vel = self.robot.data.root_ang_vel_b

        gravity_w = torch.tensor([0.0, 0.0, -1.0], dtype=torch.float32)
        projected_gravity = lab_math.quat_apply_inverse(base_quat, gravity_w)

        if self.cfg.enable_safety_fallback and projected_gravity[2] > -0.5:
            print(
                "\nFalling detected, stopping policy for safety. "
                "You can disable safety fallback by setting "
                f"{self.cfg.__class__.__name__}.enable_safety_fallback "
                "to False."
            )
            self.controller.stop()

        cmd = self.controller.vel_command
        cmd_t = torch.tensor(
            [cmd.lin_vel_x, cmd.lin_vel_y, cmd.ang_vel_yaw], dtype=torch.float32
        )

        phase = (self._t * self.gait_freq_hz) % 1.0
        angle = 2.0 * math.pi * phase
        gait = torch.tensor([math.cos(angle), math.sin(angle)], dtype=torch.float32)

        leg_pos = dof_pos[self.real_indices]
        leg_vel = dof_vel[self.real_indices]
        leg_default = self.robot.default_joint_pos[self.real_indices]
        joint_pos_rel = leg_pos - leg_default

        return torch.cat([
            cmd_t,
            gait,
            projected_gravity,
            base_ang_vel,
            joint_pos_rel,
            leg_vel,
            self.last_raw_action,
        ], dim=0)

    def _flatten_history(self) -> torch.Tensor:
        """Return term-major flatten: [term_i_t0..tN] for each term, then concat."""
        assert self._step_buf is not None
        parts = []
        for i in range(len(_TERM_DIMS)):
            s = self._term_offsets[i]
            e = self._term_offsets[i + 1]
            parts.append(self._step_buf[:, s:e].reshape(-1))
        return torch.cat(parts, dim=0)

    def inference(self) -> torch.Tensor:
        obs = self._per_step_obs()

        if self._step_buf is None:
            # Initialize history with the current obs in every slot (rather than
            # zeros) so the policy sees a stable input before any motion.
            self._step_buf = obs.unsqueeze(0).expand(self.history_length, -1).clone()
        else:
            self._step_buf = self._step_buf.roll(shifts=-1, dims=0)
            self._step_buf[-1] = obs.clamp(-100.0, 100.0)

        flat = self._flatten_history()

        with torch.no_grad():
            action = self._model(flat).squeeze(0)
            action = torch.clamp(action, -100.0, 100.0)

        self.last_raw_action = action.clone()
        self._t += self.controller.cfg.policy_dt

        leg_default = self.robot.default_joint_pos[self.real_indices]
        leg_targets = leg_default + action * self.action_scale

        dof_targets = self.robot.default_joint_pos.clone()
        dof_targets.scatter_(0, self.real_indices, leg_targets)
        return dof_targets


@configclass
class K1VelocityPolicyCfg(PolicyCfg):
    constructor = K1VelocityPolicy
    checkpoint_path: str = MISSING  # type: ignore
    actor_obs_history_length: int = 5
    action_scale: float = 0.25
    gait_freq_hz: float = 2.0
    policy_joint_names: list[str] = MISSING  # type: ignore


# 12-DoF leg joint order assigned by Isaac Lab to the K1 locomotion asset.
# Verified empirically by inspecting ``robot.joint_names`` after env init.
K1_VELOCITY_POLICY_JOINTS: list[str] = [
    "Left_Hip_Pitch", "Right_Hip_Pitch",
    "Left_Hip_Roll",  "Right_Hip_Roll",
    "Left_Hip_Yaw",   "Right_Hip_Yaw",
    "Left_Knee_Pitch", "Right_Knee_Pitch",
    "Left_Ankle_Pitch", "Right_Ankle_Pitch",
    "Left_Ankle_Roll",  "Right_Ankle_Roll",
]


@configclass
class K1VelocityControllerCfg(ControllerCfg):
    """Controller for the K1 velocity-tracking policy.

    Default leg pose matches the training asset's ``init_state`` so that the
    ``joint_pos_rel`` observation and the action offset target the same
    reference pose seen during training.
    """

    robot = K1_CFG.replace(  # type: ignore
        default_joint_pos=[
            # head
            0.0, 0.0,
            # left arm (shoulder_pitch, shoulder_roll, elbow_pitch, elbow_yaw)
            0.2, -1.25, 0.0, -0.5,
            # right arm
            0.2,  1.25, 0.0,  0.5,
            # left leg (hip_pitch, hip_roll, hip_yaw, knee_pitch, ankle_pitch, ankle_roll)
            -0.15, 0.0, 0.0, 0.3, -0.15, 0.0,
            # right leg
            -0.15, 0.0, 0.0, 0.3, -0.15, 0.0,
        ],
        # Match training PD gains (BOOSTER_K1_LOCOMOTION_CFG):
        #   hips/knees: kp=350, kd=7.5     ankles: kp=250, kd=5.0
        joint_stiffness=[
            4.0, 4.0,
            20.0, 20.0, 20.0, 20.0,
            20.0, 20.0, 20.0, 20.0,
            350.0, 350.0, 350.0, 350.0, 250.0, 250.0,
            350.0, 350.0, 350.0, 350.0, 250.0, 250.0,
        ],
        joint_damping=[
            1.0, 1.0,
            2.0, 2.0, 2.0, 2.0,
            2.0, 2.0, 2.0, 2.0,
            7.5, 7.5, 7.5, 7.5, 5.0, 5.0,
            7.5, 7.5, 7.5, 7.5, 5.0, 5.0,
        ],
        # Match training effort_limit_sim (knee bumped 40 → 60).
        effort_limit=[
            6, 6,
            14, 14, 14, 14,
            14, 14, 14, 14,
            30, 35, 20, 60, 20, 20,
            30, 35, 20, 60, 20, 20,
        ],
    )
    vel_command: VelocityCommandCfg = VelocityCommandCfg(
        vx_max=1.0, vy_max=0.5, vyaw_max=1.0,
    )
    policy: K1VelocityPolicyCfg = K1VelocityPolicyCfg(
        policy_joint_names=K1_VELOCITY_POLICY_JOINTS,
    )
