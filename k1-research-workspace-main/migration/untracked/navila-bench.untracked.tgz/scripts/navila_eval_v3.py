"""
NaVILA-Bench evaluation for the K1 VLN-CE v3 policy.

This is a sibling of `navila_eval.py` that:
  * loads the v3 ActorCritic state-dict directly into a fresh
    nn.Sequential (skips rsl_rl OnPolicyRunner so we don't need the
    v3 agent.yaml to live inside NaVILA-Bench)
  * uses `VLNEnvWrapperV3` which builds the v3 47-dim per-step obs +
    5-frame term-major history flatten from raw scene state
  * everything else (VLM image loop, R2R episode handling, measurements,
    video writer) mirrors navila_eval.py.

Usage:
  python scripts/navila_eval_v3.py
      --task=k1_matterport_vision
      --num_envs=1
      --headless --enable_cameras
      --checkpoint=<absolute path to v3 model_*.pt>
      [--episode_idx=N]
      [--gait_phase_init=0.0]
"""

import argparse
import gymnasium as gym
import os
import json
import math
import torch
import torch.nn as nn
import numpy as np
import imageio
from PIL import Image
import base64
import io
import socket

from omni.isaac.lab.app import AppLauncher

# local imports
import cli_args  # isort: skip

parser = argparse.ArgumentParser(description="Eval K1 VLN-CE v3 policy.")
parser.add_argument("--disable_fabric", action="store_true", default=False)
parser.add_argument("--num_envs", type=int, default=1)
parser.add_argument("--task", type=str, default="k1_matterport_vision")
parser.add_argument("--seed", type=int, default=None)
parser.add_argument("--episode_idx", type=int, default=0)
parser.add_argument("--gait_phase_init", type=float, default=0.0,
                    help="Initial gait clock offset in [0, 1).")
parser.add_argument("--vlm_host", type=str, default="localhost")
parser.add_argument("--vlm_port", type=int, default=54321)
parser.add_argument("--device", type=str, default="cuda")
parser.add_argument("--out_tag", type=str, default="v3",
                    help="Suffix for eval_results/k1_matterport_vision_loco_<tag>/")
cli_args.add_rsl_rl_args(parser)   # adds --checkpoint among others
AppLauncher.add_app_launcher_args(parser)
args_cli = parser.parse_args()
if not args_cli.checkpoint:
    raise SystemExit("--checkpoint is required (absolute path to v3 model_*.pt)")

# launch omniverse app
app_launcher = AppLauncher(args_cli)
simulation_app = app_launcher.app

# imports that need the SimulationApp running
import omni.isaac.lab_tasks  # noqa: F401
from omni.isaac.lab_tasks.utils import parse_env_cfg
from omni.isaac.lab_tasks.utils.wrappers.rsl_rl import RslRlVecEnvWrapper
import omni.isaac.lab.sim as sim_utils

from omni.isaac.vlnce.config import *
from omni.isaac.vlnce.utils import ASSETS_DIR, VLNEnvWrapperV3
from omni.isaac.vlnce.utils.eval_utils import (
    get_vel_command, read_episodes,
    add_instruction_on_img, InstructionData,
)


# --------------------------------------------------------------------------- #
# v3 actor builder — must match the training arch exactly (235 → 512 → 256
# → 128 → 12, ELU). The checkpoint has only `actor.*` and `critic.*` weights
# (no normalizer), so we just lift the actor.* keys.
# --------------------------------------------------------------------------- #
def build_v3_actor(ckpt_path: str, device: str) -> nn.Sequential:
    ck = torch.load(ckpt_path, map_location=device, weights_only=False)
    sd = ck["model_state_dict"]
    actor = nn.Sequential(
        nn.Linear(235, 512), nn.ELU(),
        nn.Linear(512, 256), nn.ELU(),
        nn.Linear(256, 128), nn.ELU(),
        nn.Linear(128, 12),
    )
    own = actor.state_dict()
    mapped = {}
    for k, v in sd.items():
        if not k.startswith("actor."):
            continue
        local_k = k[len("actor."):]
        if local_k in own:
            mapped[local_k] = v
    missing = [k for k in own if k not in mapped]
    if missing:
        raise RuntimeError(f"missing actor keys: {missing}")
    actor.load_state_dict(mapped, strict=True)
    actor.to(device).eval()
    iter_ = ck.get("iter", "?")
    print(f"[v3] loaded actor from {ckpt_path}  iter={iter_}  "
          f"params={sum(p.numel() for p in actor.parameters())}")
    return actor


def quat2eulers(q0, q1, q2, q3):
    roll = math.atan2(2 * (q2 * q3 + q0 * q1),
                       q0**2 - q1**2 - q2**2 + q3**2)
    pitch = math.asin(2 * (q1 * q3 - q0 * q2))
    yaw = math.atan2(2 * (q1 * q2 + q0 * q3),
                      q0**2 + q1**2 - q2**2 - q3**2)
    return roll, pitch, yaw


def reset_start_pos_rot(env_cfg, args_cli, episode):
    scene_id = os.path.splitext(os.path.basename(episode["scene_id"]))[0]
    env_cfg.scene.terrain.obj_filepath = os.path.join(
        ASSETS_DIR, f"matterport_usd/{scene_id}/{scene_id}.usd"
    )
    start_pos = episode["start_position"]
    start_rot = episode["start_rotation"]
    goal_pos = episode["reference_path"][-1]
    env_cfg.scene.robot.init_state.rot = start_rot
    env_cfg.scene.robot.init_state.pos = (
        start_pos[0], start_pos[1], start_pos[2] + 0.55
    )
    env_cfg.scene.terrain.origins = env_cfg.scene.robot.init_state.pos
    env_cfg.scene.disk_1.init_state.pos = (
        [start_pos[0], start_pos[1], start_pos[2] + 2.5]
    )
    env_cfg.scene.disk_2.init_state.pos = (
        [goal_pos[0], goal_pos[1], goal_pos[2] + 2.5]
    )
    return env_cfg


def sample_images_and_send_to_vlm(image_list, vlm_host, vlm_port, query):
    if len(image_list) == 0:
        return None
    if len(image_list) < 8:
        image_list = image_list.copy()
        for _ in range(8 - len(image_list)):
            image_list.insert(0, Image.new('RGB', image_list[-1].size, (0, 0, 0)))
    else:
        image_list = image_list.copy()
    num_images = len(image_list)
    indices = [int(i * (num_images - 1) / 7) for i in range(7)]
    sampled_images = [image_list[i] for i in indices]
    sampled_images.append(image_list[-1])

    encoded_images = []
    for image in sampled_images:
        if isinstance(image, np.ndarray):
            arr = image
            if arr.dtype != np.uint8:
                arr = ((arr * 255.0) if arr.max() <= 1.0 else arr).clip(
                    0, 255
                ).astype(np.uint8)
            pil_image = Image.fromarray(arr)
        elif isinstance(image, Image.Image):
            pil_image = image
        else:
            pil_image = Image.fromarray(np.array(image, dtype=np.uint8))
        buf = io.BytesIO()
        pil_image.save(buf, format="JPEG")
        encoded_images.append(base64.b64encode(buf.getvalue()).decode())

    request_data = {'images': encoded_images, 'query': query}
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((vlm_host, vlm_port))
        data_bytes = json.dumps(request_data).encode()
        s.sendall(len(data_bytes).to_bytes(8, 'big'))
        s.sendall(data_bytes)
        size_data = s.recv(8)
        size = int.from_bytes(size_data, 'big')
        response_data = b''
        while len(response_data) < size:
            packet = s.recv(4096)
            if not packet:
                break
            response_data += packet
        return json.loads(response_data.decode())


def main():
    r2r_data_path = os.path.join(ASSETS_DIR, "vln_ce_isaac_v1.json.gz")
    all_episodes = read_episodes(r2r_data_path)
    episode = all_episodes[args_cli.episode_idx]

    env_cfg = parse_env_cfg(args_cli.task, num_envs=args_cli.num_envs)
    env_cfg = reset_start_pos_rot(env_cfg, args_cli, episode)

    env = gym.make(args_cli.task, cfg=env_cfg, render_mode=None)
    env = RslRlVecEnvWrapper(env)

    # Build the v3 actor directly (skip rsl_rl runner setup).
    device = env.unwrapped.device
    actor = build_v3_actor(args_cli.checkpoint, device=str(device))

    # Build a callable that turns the 235-dim policy input into 12-dim
    # actions deterministically (mean of the policy, no exploration).
    def policy_fn(obs_235: torch.Tensor) -> torch.Tensor:
        with torch.no_grad():
            return actor(obs_235)

    # Drop the v3-specific wrapper on top.
    env = VLNEnvWrapperV3(
        env, policy_fn, args_cli.task, episode,
        high_level_obs_key="camera_obs",
        gait_phase_init=args_cli.gait_phase_init,
    )

    # Camera setup
    robot_pos_w = env.unwrapped.scene["robot"].data.root_pos_w[0].detach().cpu().numpy()
    robot_quat_w = env.unwrapped.scene["robot"].data.root_quat_w[0].detach().cpu().numpy()
    _, _, yaw = quat2eulers(*robot_quat_w)
    cam_eye = (robot_pos_w[0] - 0.8 * math.sin(-yaw),
               robot_pos_w[1] - 0.8 * math.cos(-yaw),
               robot_pos_w[2] + 0.8)
    cam_target = tuple(robot_pos_w)
    env.unwrapped.sim.set_camera_view(eye=cam_eye, target=cam_target)

    obs, infos = env.reset()

    steps_per_image = 0.5 / (env.unwrapped.cfg.sim.dt * env.unwrapped.cfg.decimation)
    steps_per_viz_image = 0.1 / (env.unwrapped.cfg.sim.dt * env.unwrapped.cfg.decimation)

    rgb_obs = infos["observations"]["camera_obs"]
    init_frame = rgb_obs[0, :, :, :3].cpu().numpy()
    instruction = InstructionData(**episode["instruction"])
    image_observations = [Image.fromarray(init_frame)]

    add_instruction_on_img(init_frame, instruction.instruction_text)
    vis_frame = infos["observations"]["viz_camera_obs"][0, :, :, :3].cpu().numpy()
    add_instruction_on_img(vis_frame, "")
    rgb_obses = [np.concatenate([init_frame, vis_frame], axis=1)]

    num_steps = 0
    target_steps = 0
    same_pos_count = 0
    prev_pos = env.unwrapped.scene["robot"].data.root_pos_w[0].detach().cpu().numpy()
    max_episode_steps = 100 * 0.5 / (env.unwrapped.cfg.sim.dt * env.unwrapped.cfg.decimation)

    # Pre-VLM warmup: fill the 8-frame VLM image buffer with REAL frames.
    zero_cmd = torch.zeros(3, device=obs.device)
    warmup_target_frames = 8
    warmup_total_steps = int(warmup_target_frames * steps_per_image)
    for warm_i in range(warmup_total_steps):
        obs, _, done, infos = env.step(zero_cmd)
        if (warm_i + 1) % int(steps_per_image) == 0:
            curr_frame = (
                infos["observations"]["camera_obs"][0, :, :, :3].cpu().numpy()
            )
            image_observations.append(Image.fromarray(curr_frame))
    prev_pos = env.unwrapped.scene["robot"].data.root_pos_w[0].detach().cpu().numpy()

    vlm_vel_commands = [0.0, 0.0, 0.0]
    env_steps_to_go = 0
    stream_output = ""

    while simulation_app.is_running():
        with torch.inference_mode():
            if num_steps == target_steps:
                stream_output = sample_images_and_send_to_vlm(
                    image_observations, args_cli.vlm_host, args_cli.vlm_port,
                    instruction.instruction_text,
                )
                vlm_vel_commands, time_to_go = get_vel_command(stream_output)
                env_steps_to_go = int(time_to_go / (
                    env.unwrapped.cfg.sim.dt * env.unwrapped.cfg.decimation
                ))
                target_steps = num_steps + env_steps_to_go
                print(f"VLM: {stream_output}\nCmd: {vlm_vel_commands}  "
                      f"steps_to_go: {env_steps_to_go}")

        obs, _, done, infos = env.step(
            torch.tensor(vlm_vel_commands, device=obs.device, dtype=torch.float32)
        )

        if done or env.is_stop_called or num_steps > max_episode_steps:
            break

        cur_pos = env.unwrapped.scene["robot"].data.root_pos_w[0].detach().cpu().numpy()
        robot_vel = np.linalg.norm(
            env.unwrapped.scene["robot"].data.root_vel_w[0].detach().cpu().numpy()
        )
        if np.linalg.norm(cur_pos - prev_pos) < 0.01 and robot_vel < 0.01:
            same_pos_count += 1
        else:
            same_pos_count = 0
        prev_pos = cur_pos
        if same_pos_count >= 1000:
            print("Same-pos 1000 steps — breaking.")
            break

        if num_steps % steps_per_image == 0:
            curr_frame = infos["observations"]["camera_obs"][0, :, :, :3].cpu().numpy()
            image_observations.append(Image.fromarray(curr_frame))
            curr_frame_copy = curr_frame.copy()
            add_instruction_on_img(curr_frame_copy, instruction.instruction_text)
        if num_steps % steps_per_viz_image == 0:
            curr_vis_frame = infos["observations"]["viz_camera_obs"][0, :, :, :3].cpu().numpy()
            add_instruction_on_img(curr_vis_frame, stream_output)
            rgb_obses.append(np.concatenate([curr_frame_copy, curr_vis_frame], axis=1))

        num_steps += 1
        if env_steps_to_go == 0:
            env.set_stop_called(True)

    measurements = infos["measurements"]
    result_dir = f"eval_results/{args_cli.task}_loco_{args_cli.out_tag}"
    os.makedirs(result_dir, exist_ok=True)
    measurement_dir = os.path.join(result_dir, "measurements")
    os.makedirs(measurement_dir, exist_ok=True)
    with open(f"{measurement_dir}/{int(episode['episode_id'])-1}.json", "w") as f:
        json.dump(measurements, f, indent=4)

    video_dir = os.path.join(result_dir, "videos")
    os.makedirs(video_dir, exist_ok=True)
    writer = imageio.get_writer(
        f"{video_dir}/output_{int(episode['episode_id'])-1}.mp4", fps=10
    )
    for frame in rgb_obses:
        writer.append_data(frame.astype(np.uint8))
    writer.close()

    env.close()


if __name__ == "__main__":
    main()
    simulation_app.close()
