# SPDX-License-Identifier: BSD-3-Clause
"""
VLNEnvWrapperV3 — drives the K1 VLN-CE v3 policy from the NaVILA-Bench
benchmark loop.

The v3 policy was trained with a 47-dim per-step observation +
5-frame history, term-major flattened to 235 dims:

  per-step (in order):
    velocity_commands(3)  gait_phase(2)  projected_gravity(3)
    base_ang_vel(3)  joint_pos_rel(12)  joint_vel_rel(12)  last_action(12)
  history = 5 frames
  flatten = [cmd_t0..t4 | gait_t0..t4 | grav_t0..t4 | angv_t0..t4
             | jp_t0..t4 | jv_t0..t4 | la_t0..t4]   (235 dim)

action_scale was 0.25 in training. The bench's existing
k1_matterport_vision env uses scale=0.5, so we pre-divide the policy
action by 2 before calling env.step(), giving an effective scale of
0.25. (action × 0.5 by env × 0.5 by us = action × 0.25.)

This wrapper IGNORES the env's "policy" observation group (the 235-dim
single-step layout from k1_matterport_vision_cfg.py); it constructs the
v3 obs directly from scene state. The env is used only as a physics
engine + Matterport scene + camera renderer + measurement manager.
"""

from __future__ import annotations

import math
import torch

from omni.isaac.lab.envs import ManagerBasedRLEnv
from .measures import add_measurement


GAIT_FREQ_HZ = 2.0
HISTORY_LENGTH = 5
PER_STEP_DIM = 47   # 3+2+3+3+12+12+12
ACTION_SCALE_RATIO = 0.5   # v3 wants 0.25; env uses 0.5 → pre-divide by 2


def quat_apply_inverse(q_wxyz: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    """Passive rotation by q^-1 applied to vector v. q_wxyz: (..., 4),
    v: (..., 3). Returns (..., 3)."""
    w = q_wxyz[..., 0:1]
    qv = q_wxyz[..., 1:4]
    t = 2.0 * torch.cross(qv, v, dim=-1)
    return v - w * t + torch.cross(qv, t, dim=-1)


class VLNEnvWrapperV3:
    """Drives the K1 v3 policy through the bench's Matterport env.

    Use with a single env (num_envs=1). Maintains an internal 47-dim ×
    5-frame history buffer and feeds the policy the term-major flattened
    235-dim observation each step.
    """

    def __init__(
        self,
        env,                         # already wrapped with RslRlVecEnvWrapper
        low_level_policy,
        task_name: str,
        episode,
        max_length: int = 10000,
        high_level_obs_key: str = "camera_obs",
        gait_phase_init: float = 0.0,
        measure_names=("PathLength", "DistanceToGoal", "Success",
                       "SPL", "OracleNavigationError", "OracleSuccess"),
    ):
        self.env = env
        self.task_name = task_name
        self.episode = episode
        self.high_level_obs_key = high_level_obs_key
        self.max_length = max_length
        self.measure_names = list(measure_names)

        self.low_level_policy = low_level_policy
        self.low_level_action = None

        self.env_step = 0
        self.same_pos_count = 0
        self.curr_pos = None
        self.prev_pos = None
        self.is_stop_called = False

        # v3 obs / gait state, allocated lazily on first reset() since
        # the env hasn't computed obs yet at construct time.
        self.device = self.env.unwrapped.device
        self.num_envs = self.env.unwrapped.num_envs
        self._history_buf = None     # (num_envs, HISTORY_LENGTH, PER_STEP_DIM)
        self._last_action = torch.zeros(
            self.num_envs, 12, device=self.device, dtype=torch.float32
        )
        self._gait_phase = torch.full(
            (self.num_envs,), float(gait_phase_init),
            device=self.device, dtype=torch.float32,
        )
        # cmd is whatever the VLM most-recently said.
        self._command = torch.zeros(
            self.num_envs, 3, device=self.device, dtype=torch.float32
        )
        self._policy_dt = (
            self.env.unwrapped.cfg.sim.dt * self.env.unwrapped.cfg.decimation
        )

    @property
    def unwrapped(self) -> ManagerBasedRLEnv:
        return self.env.unwrapped

    def set_measures(self):
        self.measure_manager = add_measurement(
            self.env, self.episode, self.measure_names
        )

    # ---- v3 obs construction ----
    def _per_step_obs(self) -> torch.Tensor:
        """Build the 47-dim per-step v3 obs from raw scene state.
        Returns (num_envs, 47)."""
        robot = self.unwrapped.scene["robot"].data
        # body-frame angular velocity is already body-frame in Isaac Lab
        ang_vel_b = robot.root_ang_vel_b      # (num_envs, 3)
        # projected_gravity: gravity in body frame
        # Isaac Lab convention: gravity_world = (0, 0, -1), projected = q^-1 * g
        gravity_w = torch.tensor(
            [0.0, 0.0, -1.0], device=self.device, dtype=torch.float32
        ).expand(self.num_envs, 3)
        proj_grav = quat_apply_inverse(robot.root_quat_w, gravity_w)
        # joint_pos_rel = current - default; joint_vel_rel = current vel
        # (rsl_rl's joint_vel_rel uses zero default — same as raw joint_vel)
        jp_rel = robot.joint_pos - robot.default_joint_pos
        jv = robot.joint_vel

        # gait_phase obs: cos/sin of 2π × phase
        angle = 2.0 * math.pi * self._gait_phase
        gait = torch.stack([torch.cos(angle), torch.sin(angle)], dim=-1)

        return torch.cat([
            self._command,    # 3
            gait,             # 2
            proj_grav,        # 3
            ang_vel_b,        # 3
            jp_rel,           # 12
            jv,               # 12
            self._last_action,  # 12
        ], dim=-1)

    def _flatten_history_term_major(self) -> torch.Tensor:
        """history_buf: (N, H, 47). Return (N, 235) term-major flatten."""
        # term boundaries: (3, 2, 3, 3, 12, 12, 12)
        offsets = [0, 3, 5, 8, 11, 23, 35, 47]
        parts = []
        for i in range(7):
            s, e = offsets[i], offsets[i + 1]
            # buf[:, :, s:e] is (N, H, d); reshape to (N, H*d) row-major
            # → time outer, joint inner.
            parts.append(self._history_buf[:, :, s:e].reshape(self.num_envs, -1))
        return torch.cat(parts, dim=-1)

    def _build_policy_input(self) -> torch.Tensor:
        """Pull one per-step obs into the history buffer and return the
        flattened 235-dim policy input."""
        obs = self._per_step_obs()
        if self._history_buf is None:
            # Initialize buffer by replicating current obs in all H slots —
            # matches what booster_deploy's K1VelocityPolicy.inference does
            # on first step (and is reasonable for a clean reset).
            self._history_buf = obs.unsqueeze(1).expand(
                -1, HISTORY_LENGTH, -1
            ).clone()
        else:
            self._history_buf = torch.roll(
                self._history_buf, shifts=-1, dims=1
            )
            self._history_buf[:, -1, :] = obs
        return self._flatten_history_term_major()

    # ---- gym-ish API ----
    def reset(self):
        low_level_obs, infos = self.env.reset()
        # First-reset bookkeeping: state buffers + gait clock + history.
        self._history_buf = None
        self._last_action.zero_()
        self._command.zero_()
        # gait phase keeps its init value (from ctor) until first step;
        # if you want a fresh random phase per episode, override here.

        # Warmup: same as the original VLNEnvWrapper. Step with zero cmd
        # for the task-specific number of frames so the VLM image buffer
        # has real (not black) frames before NaVILA's first call.
        if "go2" in self.task_name:
            warmup_steps = 100
        elif "h1" in self.task_name or "g1" in self.task_name:
            warmup_steps = 200
        else:
            warmup_steps = 50
        for i in range(warmup_steps):
            if i % 100 == 0 or i == warmup_steps - 1:
                print(f"[v3-wrapper] warmup step {i}/{warmup_steps}")
            policy_input = self._build_policy_input()
            action = self.low_level_policy(policy_input)
            # advance gait clock
            self._gait_phase = (
                self._gait_phase + GAIT_FREQ_HZ * self._policy_dt
            ) % 1.0
            self._last_action = action
            # Pre-divide so env's scale=0.5 yields effective 0.25
            scaled = action * ACTION_SCALE_RATIO
            low_level_obs, _, _, infos = self.env.step(scaled)

        self.env_step = 0
        self.same_pos_count = 0
        self.set_measures()
        self.measure_manager.reset_measures()
        infos["measurements"] = self.measure_manager.get_measurements()
        self.prev_pos = (
            self.env.unwrapped.scene["robot"].data.root_pos_w[0].detach()
        )
        obs = infos["observations"][self.high_level_obs_key]
        return obs, infos

    def update_command(self, command) -> None:
        """High-level planner pushes a (vx, vy, wz) command. We just store
        it; it shows up in the next per-step obs at term[0]."""
        if not torch.is_tensor(command):
            command = torch.tensor(
                command, device=self.device, dtype=torch.float32
            )
        if command.dim() == 1:
            command = command.unsqueeze(0).expand(self.num_envs, -1)
        self._command = command.clone()

    def step(self, action):
        """High-level action = velocity command. The low-level policy is
        called internally and produces the joint action."""
        self.update_command(action)
        policy_input = self._build_policy_input()
        low_level_action = self.low_level_policy(policy_input)
        self._gait_phase = (
            self._gait_phase + GAIT_FREQ_HZ * self._policy_dt
        ) % 1.0
        self._last_action = low_level_action
        scaled = low_level_action * ACTION_SCALE_RATIO
        low_level_obs, reward, done, info = self.env.step(scaled)
        obs = info["observations"][self.high_level_obs_key]
        self.env_step += 1
        self.measure_manager.update_measures()
        info["measurements"] = self.measure_manager.get_measurements()
        same_pos = self.check_same_pos()
        done = done[0] or same_pos or self.env_step >= self.max_length \
            or self.is_stop_called
        return obs, reward, done, info

    def check_same_pos(self) -> bool:
        curr_pos = self.env.unwrapped.scene["robot"].data.root_pos_w[0].detach()
        robot_vel = torch.norm(
            self.env.unwrapped.scene["robot"].data.root_vel_w[0].detach()
        )
        if torch.norm(curr_pos - self.prev_pos) < 0.01 and robot_vel < 0.1:
            self.same_pos_count += 1
        else:
            self.same_pos_count = 0
        self.prev_pos = curr_pos
        if self.same_pos_count >= 1000:
            print("[v3-wrapper] same-pos 1000 steps — breaking")
            return True
        return False

    def set_stop_called(self, is_stop_called: bool) -> None:
        self.env.is_stop_called = is_stop_called
        self.is_stop_called = is_stop_called

    def close(self) -> None:
        self.env.close()
